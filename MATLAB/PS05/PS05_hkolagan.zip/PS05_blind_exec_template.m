your function definition line goes here
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ENGR 132 
% Program Description 
%	...
%
% Function Call
% 	...
%
% Input Arguments
%	1. ...
%
% Output Arguments
%	1. ...
%
% Assigment Information
%   Assignment:    PS ##, Problem #
%   Author:        Name, login@purdue.edu
%  	Team ID:       ###-##
%  	Contributor:   Name, login@purdue [repeat for each]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% ____________________
%% INITIALIZATION



%% ____________________
%% CALCULATIONS



%% ____________________
%% FORMATTED TEXT DISPLAY



%% ____________________
%% COMMAND WINDOW OUTPUTS



%% ____________________
%% ACADEMIC INTEGRITY STATEMENT
% I/We have not used source code obtained from any other unauthorized
% source, either modified or unmodified.  Neither have I/we provided
% access to my/our code to another. The project I/we am/are submitting
% is my/our own original work.
%