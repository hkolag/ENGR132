function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ENGR 132 
% Program Description 
%  
%
% Function Call
% 	
%
% Input Arguments
%   
%
% Output Arguments
%   
%
% Assigment Information
%   Assignment:         PS ##, Problem #
%   Author:             Harith Kolaganti, hkolagan@purdue.edu
%   Team ID:            ###-##
%  	Paired Programmer:  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% ____________________
%% VARIABLE ASSIGNMENTS


%% ____________________
%% CALCULATIONS

%% ____________________
%% ACADEMIC INTEGRITY STATEMENT
% I/We have not used source code obtained from any other unauthorized
% source, either modified or unmodified.  Neither have I/we provided
% access to my/our code to another. The project I/we am/are submitting
% is my/our own original work.
%